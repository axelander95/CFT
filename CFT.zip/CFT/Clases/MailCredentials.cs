﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace CFT.Clases
{
    public class MailCredentials
    {
        public static string hostname = "smtp.mandrillapp.com";
        public static int port = 587;
        public static string user = "andres_ldoi@hotmail.com";
        public static string token = "aTwurQ_v5I3bTRCQO52mNQ";
    }
}